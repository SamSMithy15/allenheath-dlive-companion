## Allen & Heath dLive (two-way)

Controls a dLive MixRack or Surface over the **dLive MIDI over TCP/IP protocol (firmware V2.0+)**. It also reads the desk's state back as variables and feedbacks.

### Setup

1. On the dLive:
   - **Utility → Control → MixRack Security**: Security Level **No Security** (plain TCP) or **SSL** (TLS). "Disable TCP MIDI" blocks this module.
   - **Utility → Control → MIDI**: note the **MIDI Channels** base N, and enable both **Send** and **Receive** MIDI (Send off = no feedback, Receive off = no control).
   - The MixRack IP is under **MixRack Setup → Config → Network** (factory default 192.168.1.70).
2. Here, enter the **MixRack IP** (or the Surface IP if you choose **Surface**) and choose **MixRack** or **Surface**.
   - Leave the port at `0` to use the default: MixRack 51325, or 51327 with TLS; Surface 51328, or 51329 with TLS.
   - Set the same **MIDI base channel** as the desk (1-12). The desk uses channels N to N+4.
3. For TLS, also enter the user profile (0-31) and password.

### Actions

- **Fader:**
  - Set to an exact dB value (e.g. `-12.5`, `+6`, `-inf`). Values snap to the nearest 0.5 dB step, and the real value is shown.
  - Increase or decrease by any amount per button.
  - Read the level from the desk (the value is returned as the action result).
- **Mute:** on / off / toggle / set state.
- **Recall:** scene 1-500 (MixRack only), or cue list recall id 0-1999 (Surface only).
- **Assignments:** main mix (on / off / toggle), DCA 1-24, mute group 1-8.
- **Sends:** Aux / FX / Matrix send level (dB); input to group / aux on / off.
- **Channel:** name (max 8 ASCII characters) and colour.
- **Preamp:** gain (+5 to +60 dB), pad, 48V.
- **Request all current values again.**

### Variables

Use `$(label:id)`. Per-channel variables:

- `input_1_level` (`-12.5`, `0.0`, `+10.0`, `-inf`)
- `input_1_mute` (`true` / `false`)
- `input_1_name`
- `input_1_colour`
- `input_1_main`

The same pattern applies to `mono_group`, `stereo_group`, `mono_aux`, `stereo_aux`, `mono_matrix`, `stereo_matrix`, `mono_fx_send`, `stereo_fx_send`, `fx_return`, `main`, `dca`, `mute_group`, `ufx_send` and `ufx_return`.

Global variables: `connection_status`, `connected`, `scene`, `cue`, `last_read_level`, `last_read_channel`, `rx_discarded_bytes`.

### Feedbacks

Channel muted, connected, scene is the last recalled, fader level compared with a dB value, input assigned to main.

### Notes

- **On connect:** the module requests the current state. It sends about 1,600 requests at 128 inputs, about 8 s. Lower "Inputs to track" to shorten this. Buttons pressed meanwhile go first.
- **Scene number:** the protocol has no "current scene" query. `scene` fills in on the first recall after connecting.
- **Connection loss:** the module detects it and reconnects with backoff (1 s up to 30 s).
- **Troubleshooting:** turn on *Debug log every byte*.
- **Full documentation and limitations:** see README.md in the module source.
